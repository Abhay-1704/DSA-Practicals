/*Problem-9 Code (B-TREE)
Roll-No :- co23306
Name :- Abhay Pratap Singh
Cse, 2nd Year*/

#include <bits/stdc++.h>
using namespace std;

// Structure for a node in B-tree
struct Node {
    vector<int> keys;          // Keys in the node
    vector<Node*> children;    // Child pointers
    bool isLeaf;               // Flag to check if it's a leaf node
    Node* parent;              // Parent node

    Node(bool leaf = false) : isLeaf(leaf), parent(nullptr) {}
};

// Function to print B-tree level by level
void printBTree(Node* root) {
    if (root == nullptr) return;

    vector<Node*> currentLevel;
    currentLevel.push_back(root);
    int level = 0;

    while (!currentLevel.empty()) {
        vector<Node*> nextLevel;
        cout << "Level " << level << ": ";

        for (Node* node : currentLevel) {
            for (int key : node->keys) {
                cout << key << " ";
            }

            // If it's not a leaf, add its children to the next level
            if (!node->isLeaf) {
                for (Node* child : node->children) {
                    nextLevel.push_back(child);
                }
            }

            cout << "| ";  // Separator for each node
        }

        cout << endl;
        currentLevel = nextLevel;
        level++;
    }
}

// Function to create a new node
Node* createNode(bool isLeaf) {
    Node* newNode = new Node(isLeaf);
    return newNode;
}

// Function to split a full node
void splitNode(Node* parent, int index, Node* fullNode, int maxKeys) {
    Node* newNode = createNode(fullNode->isLeaf);
    int midIndex = fullNode->keys.size() / 2;
    int midKey = fullNode->keys[midIndex];

    // Move the right half of the keys and children to the new node
    for (int i = midIndex + 1; i < fullNode->keys.size(); i++) {
        newNode->keys.push_back(fullNode->keys[i]);
    }

    if (!fullNode->isLeaf) {
        for (int i = midIndex + 1; i < fullNode->children.size(); i++) {
            newNode->children.push_back(fullNode->children[i]);
            fullNode->children[i]->parent = newNode;
        }
    }

    // Remove the moved keys and children from the full node
    fullNode->keys.resize(midIndex);
    fullNode->children.resize(midIndex + 1);

    // Insert the middle key into the parent node
    parent->keys.insert(parent->keys.begin() + index, midKey);
    parent->children.insert(parent->children.begin() + index + 1, newNode);
    newNode->parent = parent;
}

// Function to insert a key into a non-full node
void insertNonFull(Node* node, int key, int maxKeys) {
    int i = node->keys.size() - 1;

    if (node->isLeaf) {
        // Insert key into the leaf node in sorted order
        node->keys.push_back(0); // Make space for new key
        while (i >= 0 && node->keys[i] > key) {
            node->keys[i + 1] = node->keys[i];
            i--;
        }
        node->keys[i + 1] = key;
    } else {
        // If the node is not a leaf, find the child where the key should be inserted
        while (i >= 0 && node->keys[i] > key) {
            i--;
        }
        i++;
        Node* child = node->children[i];

        if (child->keys.size() == maxKeys) {
            // If child is full, split it
            splitNode(node, i, child, maxKeys);

            // After splitting, check which child to insert the key into
            if (key > node->keys[i]) {
                child = node->children[i + 1];
            }
        }

        // Recursively insert the key into the appropriate child
        insertNonFull(child, key, maxKeys);
    }
}

// Function to insert a key into the B-tree
void insert(Node*& root, int key, int maxKeys) {
    if (root == nullptr) {
        root = createNode(true);
    }

    if (root->keys.size() == maxKeys) {
        // If root is full, create a new root
        Node* newRoot = createNode(false);
        newRoot->children.push_back(root);
        root->parent = newRoot;

        splitNode(newRoot, 0, root, maxKeys);

        // Set the new root
        root = newRoot;
    }

    // Insert key into the non-full root
    insertNonFull(root, key, maxKeys);
}

// Function to search a key in the B-tree
bool search(Node* root, int key) {
    if (root == nullptr) return false;

    // Traverse nodes to find the key
    for (int i = 0; i < root->keys.size(); i++) {
        if (root->keys[i] == key) {
            return true;
        } else if (!root->isLeaf && key < root->keys[i]) {
            return search(root->children[i], key);
        }
    }

    if (!root->isLeaf) {
        return search(root->children[root->keys.size()], key);
    }

    return false;
}

// Function to delete a key from a leaf node
void deleteFromLeaf(Node* node, int key) {
    auto it = find(node->keys.begin(), node->keys.end(), key);
    if (it != node->keys.end()) {
        node->keys.erase(it);
    }
}

// Function to merge two nodes
void mergeNodes(Node* parent, int index) {
    Node* leftChild = parent->children[index];
    Node* rightChild = parent->children[index + 1];
    leftChild->keys.push_back(parent->keys[index]);
    leftChild->keys.insert(leftChild->keys.end(), rightChild->keys.begin(), rightChild->keys.end());

    if (!leftChild->isLeaf) {
        leftChild->children.insert(leftChild->children.end(), rightChild->children.begin(), rightChild->children.end());
    }

    parent->keys.erase(parent->keys.begin() + index);
    parent->children.erase(parent->children.begin() + index + 1);
    delete rightChild;
}


// Function to delete a key from a non-leaf node
void deleteFromNonLeaf(Node* node, int key, int maxKeys) {
    int index = 0;
    while (index < node->keys.size() && node->keys[index] < key) {
        index++;
    }

    if (index < node->keys.size() && node->keys[index] == key) {
        if (node->children[index]->keys.size() > maxKeys / 2) {
            // If the left child has more than half the keys, get the predecessor
            Node* pred = node->children[index];
            while (!pred->isLeaf) {
                pred = pred->children[pred->keys.size()];
            }
            int predKey = pred->keys.back();
            node->keys[index] = predKey;
            deleteFromLeaf(pred, predKey);
        } else if (node->children[index + 1]->keys.size() > maxKeys / 2) {
            // If the right child has more than half the keys, get the successor
            Node* succ = node->children[index + 1];
            while (!succ->isLeaf) {
                succ = succ->children[0];
            }
            int succKey = succ->keys.front();
            node->keys[index] = succKey;
            deleteFromLeaf(succ, succKey);
        } else {
            // If neither child has enough keys, merge the children
            Node* leftChild = node->children[index];
            Node* rightChild = node->children[index + 1];
            leftChild->keys.push_back(node->keys[index]);
            leftChild->keys.insert(leftChild->keys.end(), rightChild->keys.begin(), rightChild->keys.end());

            if (!leftChild->isLeaf) {
                leftChild->children.insert(leftChild->children.end(), rightChild->children.begin(), rightChild->children.end());
            }

            node->keys.erase(node->keys.begin() + index);
            node->children.erase(node->children.begin() + index + 1);
            delete rightChild;
        }
    } else {
        Node* child = node->children[index];
        if (child->keys.size() > maxKeys / 2) {
            deleteFromNonLeaf(child, key, maxKeys);
        } else {
            Node* sibling;
            int siblingIndex;
            if (index > 0 && node->children[index - 1]->keys.size() > maxKeys / 2) {
                sibling = node->children[index - 1];
                siblingIndex = index - 1;
            } else if (index < node->keys.size() && node->children[index + 1]->keys.size() > maxKeys / 2) {
                sibling = node->children[index + 1];
                siblingIndex = index + 1;
            } else {
                mergeNodes(node, index);
                deleteFromNonLeaf(child, key, maxKeys);
            }
        }
    }
}

// Function to delete a key from the B-tree
void deleteKey(Node*& root, int key, int maxKeys) {
    if (root == nullptr) return;

    if (root->isLeaf) {
        deleteFromLeaf(root, key);
    } else {
        deleteFromNonLeaf(root, key, maxKeys);
    }

    // If root has no keys and has only one child, make the child the new root
    if (root->keys.empty() && !root->isLeaf) {
        Node* oldRoot = root;
        root = root->children[0];
        delete oldRoot;
    }
}

// Main function to test B-tree operations
int main() {
    Node* root = nullptr;
    int key;
    int degree;
    int choice;

    // Ask user for the degree of the B-tree (maximum number of keys per node)
    cout << "Enter the degree of the B-tree (must be greater than 1): ";
    cin >> degree;

    // Validate the degree input
    if (degree <= 1) {
        cout << "Degree must be greater than 1!" << endl;
        return 1;
    }

    // Set MAX_KEYS based on the degree
    int maxKeys = degree - 1;

    while (true) {
        // Menu options
        cout << "\nB-tree Operations Menu:" << endl;
        cout << "1. Insert" << endl;
        cout << "2. Delete" << endl;
        cout << "3. Search" << endl;
        cout << "4. Print" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter key to insert: ";
                cin >> key;
                insert(root, key, maxKeys);
                cout << "Key " << key << " inserted." << endl;
                break;
            
            case 2:
                cout << "Enter key to delete: ";
                cin >> key;
                deleteKey(root, key, maxKeys);
                cout << "Key " << key << " deleted." << endl;
                break;
            
            case 3:
                cout << "Enter key to search: ";
                cin >> key;
                if (search(root, key)) {
                    cout << "Key " << key << " found." << endl;
                } else {
                    cout << "Key " << key << " not found." << endl;
                }
                break;
            
            case 4:
                cout << "\nB-tree structure:" << endl;
                printBTree(root);
                break;

            case 5:
                cout << "Exiting program." << endl;
                return 0;

            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}