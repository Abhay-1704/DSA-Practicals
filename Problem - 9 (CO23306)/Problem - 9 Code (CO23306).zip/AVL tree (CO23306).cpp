#include <bits/stdc++.h>
using namespace std;

// AVL Tree Node Structure
struct Node {
    int info;
    Node* LST;
    Node* RST;
    int height;

    Node(int value) : info(value), LST(nullptr), RST(nullptr), height(1) {}
};

// Function to calculate the height of the tree
int height(Node* root) {
    if (root == nullptr) return 0;
    return root->height;
}

// Function to calculate the balance factor of a node
int balanceFactor(Node* root) {
    if (root == nullptr) return 0;
    return height(root->LST) - height(root->RST);
}

// Right rotation for balancing
Node* rightRotate(Node* y) {
    Node* x = y->LST;
    Node* T2 = x->RST;

    // Perform rotation
    x->RST = y;
    y->LST = T2;

    // Update heights
    y->height = max(height(y->LST), height(y->RST)) + 1;
    x->height = max(height(x->LST), height(x->RST)) + 1;

    return x;  // Return new root
}

// Left rotation for balancing
Node* leftRotate(Node* x) {
    Node* y = x->RST;
    Node* T2 = y->LST;

    // Perform rotation
    y->LST = x;
    x->RST = T2;

    // Update heights
    x->height = max(height(x->LST), height(x->RST)) + 1;
    y->height = max(height(y->LST), height(y->RST)) + 1;

    return y;  // Return new root
}

// Function to balance the node and perform rotations if necessary
Node* balance(Node* node, int data) {
    int balance = balanceFactor(node);

    // Left heavy case (Left-Left)
    if (balance > 1 && data < node->LST->info) {
        return rightRotate(node);  // Right rotation
    }

    // Right heavy case (Right-Right)
    if (balance < -1 && data > node->RST->info) {
        return leftRotate(node);  // Left rotation
    }

    // Left-Right heavy case (Left-Right)
    if (balance > 1 && data > node->LST->info) {
        node->LST = leftRotate(node->LST);  // Left rotation on left child
        return rightRotate(node);  // Right rotation on node
    }

    // Right-Left heavy case (Right-Left)
    if (balance < -1 && data < node->RST->info) {
        node->RST = rightRotate(node->RST);  // Right rotation on right child
        return leftRotate(node);  // Left rotation on node
    }

    return node;  // No balancing needed
}

// Function to insert a node in the AVL tree
Node* insert(Node* root, int data) {
    if (root == nullptr) {
        return new Node(data);
    }

    // Insert data
    if (data < root->info) {
        root->LST = insert(root->LST, data);
    } else if (data > root->info) {
        root->RST = insert(root->RST, data);
    } else {
        return root;  // Duplicate values are not allowed
    }

    // Update the height of this ancestor node
    root->height = max(height(root->LST), height(root->RST)) + 1;

    // Balance the node if needed
    return balance(root, data);
}

// Function to find the minimum value node (used for deletion)
Node* minNode(Node* root) {
    Node* current = root;
    while (current && current->LST != nullptr) {
        current = current->LST;
    }
    return current;
}

// Function to delete a node from the AVL tree
Node* deleteNode(Node* root, int data) {
    // Step 1: Perform standard BST delete
    if (root == nullptr) return root;

    if (data < root->info) {
        root->LST = deleteNode(root->LST, data);
    } else if (data > root->info) {
        root->RST = deleteNode(root->RST, data);
    } else {
        // Node with only one child or no child
        if (root->LST == nullptr) {
            Node* temp = root->RST;
            delete root;
            return temp;
        } else if (root->RST == nullptr) {
            Node* temp = root->LST;
            delete root;
            return temp;
        }

        // Node with two children
        Node* temp = minNode(root->RST);
        root->info = temp->info;
        root->RST = deleteNode(root->RST, temp->info);
    }

    // Step 2: Update height and balance the node
    root->height = max(height(root->LST), height(root->RST)) + 1;
    return balance(root, data);
}

// Function to search for a node in the AVL tree
Node* search(Node* root, int data) {
    if (root == nullptr || root->info == data) return root;

    if (data < root->info) return search(root->LST, data);
    return search(root->RST, data);
}

// Function for compact tree printing using level-order traversal
void printCompactTree(Node* root) {
    if (root == nullptr) return;

    // Perform level-order traversal
    queue<Node*> q;
    q.push(root);

    // Store tree structure in a 2D grid to print later
    vector<string> treeLevels;

    while (!q.empty()) {
        int levelSize = q.size();
        string levelStr = "";

        for (int i = 0; i < levelSize; ++i) {
            Node* currentNode = q.front();
            q.pop();

            if (currentNode) {
                levelStr += to_string(currentNode->info) + " ";
                q.push(currentNode->LST);
                q.push(currentNode->RST);
            } else {
                levelStr += "X ";  // Mark empty node positions as "X"
            }
        }

        // Only add non-empty levels to avoid printing excess levels
        if (!levelStr.empty()) {
            treeLevels.push_back(levelStr);
        }
    }

    // Print tree levels
    for (const string& level : treeLevels) {
        cout << level << endl;
    }
}

// Function for wide tree structure print (previous method)
void printWideTree(Node* root) {
    if (root == NULL) return;

    int h = height(root);
    int width = (1 << h) - 1;

    vector<vector<string>> tree(h, vector<string>(width, " "));

    queue<pair<Node*, int>> q;
    q.push({root, (width - 1) / 2});

    int level = 0;
    while (!q.empty() && level < h) {
        int size = q.size();
        for (int i = 0; i < size; i++) {
            // Traditional unpacking of pair instead of structured bindings
            pair<Node*, int> frontNode = q.front();
            q.pop();

            Node* node = frontNode.first;
            int col = frontNode.second;

            if (node) {
                tree[level][col] = to_string(node->info);
                q.push({node->LST, col - (1 << (h - level - 2))});
                q.push({node->RST, col + (1 << (h - level - 2))});
            }
        }
        level++;
    }

    for (const auto& row : tree) {
        for (const auto& value : row) {
            cout << setw(3) << value;
        }
        cout << endl;
    }
}

// Menu-driven interface for AVL Tree operations
int main() {
    Node* root = nullptr;

    // Pre-inserted data
    vector<int> data = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97};

    // Insert pre-inserted data into the AVL tree
    for (int value : data) {
        root = insert(root, value);
    }

    int choice, value;
    while (true) {
        cout << "AVL Tree Operations Menu:\n";
        cout << "1. Insert a node\n";
        cout << "2. Delete a node\n";
        cout << "3. Search for a node\n";
        cout << "4. Print the tree structure\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to insert: ";
                cin >> value;
                root = insert(root, value);
                cout << "Node inserted!" << endl;
                break;
            case 2:
                cout << "Enter value to delete: ";
                cin >> value;
                root = deleteNode(root, value);
                cout << "Node deleted!" << endl;
                break;
            case 3:
                cout << "Enter value to search: ";
                cin >> value;
                {
                    Node* result = search(root, value);
                    if (result != nullptr) {
                        cout << "Node " << value << " found in the tree." << endl;
                    } else {
                        cout << "Node " << value << " not found in the tree." << endl;
                    }
                }
                break;
            case 4:
                cout << "Choose tree print style:\n";
                cout << "1. Compact View\n";
                cout << "2. Wide View\n";
                cout << "Enter Choice : ";
                int printChoice;
                cin >> printChoice;
                if (printChoice == 1) {
                    printCompactTree(root);
                } else if (printChoice == 2) {
                    printWideTree(root);
                } else {
                    cout << "Invalid choice!" << endl;
                }
                break;
            case 5:
                cout << "Exiting...\n";
                return 0;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    }

    return 0;
}